var http=require('http');
var url=require('url');
var router=require('./router');

function startserver(route,handle){
http.createServer(function(request,response){
    var pathname=url.parse(request.url).pathname;
    console.log('request Came For request '+pathname);
    route(handle,pathname);
response.writeHead(200,{"Content-Type":"text/plain"});
response.write("Welcome to First Http");
response.end();
}).listen(8880);

console.log('SERVER is On & running on PORT 8880');
}

exports.startserver=startserver;