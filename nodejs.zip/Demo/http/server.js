var http=require('http');

http.createServer(function(request,response){
response.writeHead(200,{"Content-Type":"text/plain"});
response.write("Welcome to First Http");
response.end();
}).listen(8880);

console.log('SERVER is On & running on PORT 8880');