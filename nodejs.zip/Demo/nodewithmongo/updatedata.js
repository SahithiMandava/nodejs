var mongodb=require('mongodb');

var MongoClient=mongodb.MongoClient;
var url='mongodb://localhost/mobile';
MongoClient.connect(url,function(err,client){
if(err){
    console.log(err);
}else{
    console.log('Connection establish....'+url);
    var db=client.db('mobile');
    var collection=db.collection('mobiledata');
   
    collection.update({'mobid':1001},{$set:{'mobname':'iPhone 7','mobcost':700000}},function(err,res){
if(err){
    console.log(err);
}else{
    console.log('Updated Data...'+res);
}
    });
   
}
});