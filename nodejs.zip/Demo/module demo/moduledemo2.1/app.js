const obj=require("./mod1");

obj.getD();
obj.getL();
console.log(obj.temp);