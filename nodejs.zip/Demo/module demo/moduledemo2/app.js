var obj=require("./mod1.js");

obj.getData();