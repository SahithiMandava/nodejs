var fs=require('fs');

var readStream=fs.createReadStream('input.txt');
var data='';
 readStream.setEncoding('UTF8');
 readStream.on('data',function(datafrom){
data+=datafrom;
 });
 readStream.on('end',function(){
console.log(data);
 });

 var writeStream=fs.createWriteStream('output.txt');
 var writedata="Hello Welcome to Capgemini L&D";
 writeStream.write(writedata,'UTF8');
 writeStream.end();
 writeStream.on('finish',function(){
console.log('Data Written on File');
 });