module.exports=function(){
    return 'Hello';
}